This partition was created by Rufus (https://rufus.ie).
It is used for booting NTFS and exFAT partitions in UEFI mode.

For details, see https://github.com/pbatard/uefi-ntfs.